close all;
clear all; 
clc;
% read an image file and store it in the "img" variable
img = imread('cincy-tri-state.png');

% define a list of cities
cities = ["Akron", "Cleveland", "Columbus", "Dayton", "Mansfield", "Toledo", "Youngstown", "Jackson", "Lexington", "Louisville", "Paducah", "Evansville", "Fort Wayne", "Indianapolis", "South Bend"];
% define the mean temperature data for each city for each month
jan = [25.2, 25.7, 28.3, 26.3, 24.3, 23.9, 24.9, 33.9, 32, 33, 32.9, 31, 23.6, 26.5, 23.4];
feb = [28.3, 28.4, 32, 30.3, 27.3, 27, 27.7, 37.9, 36.4, 37.6, 38.1, 35.8, 27.3, 31.2, 27.3];
mar = [37.7, 37.5, 42, 40.2, 36.7, 37.2, 36.7, 47.1, 45.6, 46.9, 47.6, 45.8, 38.1, 41.7, 37.5];
apr = [48.1, 47.6, 52, 50.6, 47.2, 48.3, 47.4, 56.3, 54.6, 56.4, 57, 55.5, 49, 52, 48.3];
may = [58.8, 58.5, 62.6, 61.2, 58, 59.6, 57.6, 64.1, 63.8, 65.8, 65.9, 65.6, 60.4, 62.6, 59.6];
jun = [67.5, 67.5, 71.2, 70.2, 66.8, 68.8, 65.9, 71.4, 72.2, 74.2, 74.5, 74.8, 69.7, 71.7, 69];
jul = [71.8, 71.9, 75.1, 74.3, 71, 73, 69.9, 75, 76.1, 78.4, 78.2, 78.6, 73.4, 75.4, 73];
aug = [70.3, 70.2, 73.5, 72.3, 69.3, 70.8, 68.4, 73.8, 74.8, 77, 76.2, 76.5, 71.1, 73.5, 71];
sep = [63, 63.3, 66.5, 65.1, 62.6, 63.5, 61.5, 67.9, 68, 70.1, 69.1, 69.1, 64.1, 66.3, 63.4];
oct = [51.6, 52.2, 54.7, 53.5, 51.5, 51.8, 50.8, 57.5, 56.6, 58.5, 58, 57.3, 52.4, 54.6, 52.1];
nov = [41.1, 41.8, 43.7, 42.2, 40.5, 40.5, 40.7, 47.7, 45.9, 47.6, 46.8, 45.9, 40.6, 42.9, 40.1];
dec = [30.7, 31.1, 33.5, 31.4, 29.6, 29.2, 30.4, 38.3, 36.3, 37.6, 36.9, 35.6, 29, 31.6, 28.7]; 

% define the x and y coordinates of the cities on the image
x_cordinates = [435, 417, 347, 283, 377, 305, 467, 316, 292, 230,  72, 108, 214, 179, 163];
y_cordinates = [96,  67, 191, 218, 130,  73,  99, 381, 347, 346, 428, 382, 134, 240,  94];

% Create an empty 3D array to store the heatmaps
heatmaps = zeros(500, 500, 12);

% Create a cell array to store the month names
months = {'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'};

% Combine all monthly data into a single matrix and find the minimum value for each month
all_months = [jan(:), feb(:), mar(:), apr(:), may(:), jun(:), jul(:), aug(:), sep(:), oct(:), nov(:), dec(:)];
min_temps = min(all_months, [], 2);

% Normalize the temperatures for all months data
temps = all_months - min_temps;
normalized_temps = temps ./ std(temps, 0, 2);
normalized_temps(normalized_temps < 0) = 0;

% Loop through the months and assign the corresponding data to the heatmaps array
for i = 1:12
    % Create a variable name for the current month's data
    var_name = strcat('data_', months{i});
    % Assign the current month's data to the variable
    eval(sprintf('%s = %s(:);', var_name, months{i}));
    % Normalize the current month's data
    eval(sprintf('%s = %s - min(%s);', var_name, var_name, var_name));
    eval(sprintf('%s = %s ./ std(%s);', var_name, var_name, var_name));
    eval(sprintf('%s(%s < 0) = 0;', var_name, var_name));
    % Loop through the data points and assign them to the heatmaps array
    for j = 1:15
        heatmaps(y_cordinates(j), x_cordinates(j), i) = eval(sprintf('%s(j)', var_name));
    end
    % Smooth the heatmap using a Gaussian kernel
    density = imfilter(heatmaps(:, :, i), fspecial('gaussian', [200, 200], 10), 'replicate');
    % Overlay the heatmap on the image and display it
    omask = heatmap_overlay(img, density, 'jet');
    figure, imshow(omask), colormap(jet), colorbar, title(sprintf('Heatmap %s', months{i}));
end

