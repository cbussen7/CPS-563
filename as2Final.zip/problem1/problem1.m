close all;
clear;
clc;

%data
clothing_data = {'Dresses', 200;
                 'Jackets', 4600;
                 'Coats', 1300;
                 'Jeans', 1700};

shoes_data = {'Boots', 1800;
              'Flats', 900;
              'Heels', 2200;
              'Sandals', 2700;
              'Sneakers', 1500};

accessories_data = {'Bags', 2500;
                    'Belts', 600;
                    'Sunglasses', 140;
                    'Hats', 1100;
                    'Socks', 800};

appliances_data = {'Coffee Makers', 140;
                   'Air Fryers', 300;
                   'Blenders', 450;
                   'Pressure Cookers', 700;
                   'Stand Mixer', 110};

%join all data
all_data = {clothing_data, shoes_data, accessories_data, appliances_data};

%both of these compute the total area to be used later to calc how big each rectangle should be 
total_sales = sum(cellfun(@(x) sum(cell2mat(x(:, 2))), all_data));
category_areas = cellfun(@(x) sum(cell2mat(x(:, 2))), all_data) / total_sales;

%create nested treemaps for each category
category_rectangles = cell(1, numel(all_data));
for i = 1:numel(all_data)
    category_data = cell2mat(all_data{i}(:, 2));
    category_rectangles{i} = treemap(category_data, 1, 1);
end

%compute positions for category rectangles
total_area = 1;
width = sqrt(total_area);
height = width;

category_positions = treemap(category_areas, width, height);

%create final rectangles and labels then join them in all_rectangles
all_rectangles = [];
all_labels = {};

for i = 1:numel(all_data)
    category_rect = category_positions(:, i);
    category_width = category_rect(3);
    category_height = category_rect(4);
    item_rectangles = category_rectangles{i};
    item_rectangles(1:2, :) = item_rectangles(1:2, :) .* [category_width; category_height];
    item_rectangles(3:4, :) = item_rectangles(3:4, :) .* [category_width; category_height];
    item_rectangles(1, :) = item_rectangles(1, :) + category_rect(1);
    item_rectangles(2, :) = item_rectangles(2, :) + category_rect(2);
    
    all_rectangles = [all_rectangles, item_rectangles];
    all_labels = [all_labels; all_data{i}(:, 1)];
end

%color assignment
category_colors = [0.3, 0.8, 0.3;
                   0.2, 0.5, 0.8;
                   0.9, 0.3, 0.3;
                   0.7, 0.3, 0.8];

colors = [];
for i = 1:numel(all_data) %numel returns the number of elements in an array and assignment
    colors = [colors; repmat(category_colors(i, :), size(all_data{i}, 1), 1)]; %repmat appends a number to an array
end

%plot the conjoined treemaps
figure;
plotRectangles(all_rectangles, all_labels, colors);
hold on;
outline(all_rectangles);
hold off;
