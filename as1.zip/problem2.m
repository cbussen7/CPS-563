close all;
clear all;
clc;

altsales = readtable('ALTSALES.xls', 'VariableNamingRule', 'preserve');
x = altsales.observation_date;
y = altsales.ALTSALES;

plot(x, y);
xlabel("Observation Date");
ylabel("Vehicle Sales (millions of units)");
title("Lightweight Vehicle Sales Over Time");