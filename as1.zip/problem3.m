close all;
clear all;
clc;

big3 = readtable('big3.xlsx', 'VariableNamingRule', 'preserve');
names = big3.Name;
data = [big3.("Grand Slam"), big3.("ATP Finals"), big3.("ATP Masters"), big3.Olympics];

bar(data, 'stacked');
legend({'Grand Slam', 'ATP Finals', 'ATP Masters', 'Olympics'});
set(gca, 'XTickLabel', names);

xlabel("Player Name");
ylabel("Number of Wins");
title("Wins of the Tennis Big Three");