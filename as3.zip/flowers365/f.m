close all;
clear all;
clc;

% set path for resized images
images_path = './Resized_Images/';

% Get a list of all image files in images folder
images_files = dir(fullfile(images_path, '*.jpg'));

% Load all images into memory and concatenate their pixels into features
images_features = zeros(length(images_files), 2500);
for i = 1:length(images_files)
    image = imread(fullfile(images_path, images_files(i).name));
    images_features(i,:) = image(:)';
end

% perform pca on matrix of features
[PC, V] = pca(images_features');

% project images to 15 dimensions
projection = PC(:, 1:15);
 
image_projections = images_features * projection;
% spider_plot(image_projections(:,1:5));
 
% create labels for each image
flower_labels = zeros(length(images_files), 1);
for i = 1:length(images_files)
    if i >= 1 && i <= 10
        flower_labels(i) = 1; % dandelion
    elseif i >= 11 && i <= 20
        flower_labels(i) = 2; % rose
    elseif i >= 21 && i <= 30
        flower_labels(i) = 3; % sunflower
    elseif i >= 31 && i <= 40
        flower_labels(i) = 4; % tulip
    end
end

test_path = './Resized_Test/';

test_files = dir(fullfile(test_path, '*.jpg'));

test_features = zeros(length(test_files), 2500);
for i = 1:length(test_files)
    image = imread(fullfile(test_path, test_files(i).name));
    test_features(i,:) = image(:)';
end

test_projections = test_features * projection;

% visualize test images using radar chart and first 5 components
figure;
for i = 1:length(test_files)
    subplot(2,4,i);
    spider_plot(test_projections(:,1:5));
    set(gca,'xtick',1:5);
    title(test_files(i).name);
end
sgtitle('Radar Chart of First 5 Components of Test Images');
