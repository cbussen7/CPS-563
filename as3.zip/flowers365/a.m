close all;
clear all;
clc;

f = 'Images';
d = dir(fullfile(f,'*.jpg'));
mkdir('Resized_Images');

% Concatenated figure 1
figure(1);
clf;
tiledlayout('flow', 'Padding', 'none', 'TileSpacing', 'none');
for i = 1:length(d)
    I = imread(fullfile(f,d(i).name));
    if size(I,3) > 1
        I = rgb2gray(I);
    end
    I = imresize(I,[50,50]);
    nexttile;
    imshow(I);
    imwrite(I, fullfile('Resized_Images', strcat(num2str(i,'%02d'), '_gray.jpg')));
end

f = 'Test';
d = dir(fullfile(f,'*.jpg'));
mkdir('Resized_Test');

% Concatenated figure 2
figure(2);
clf;
tiledlayout('flow', 'Padding', 'none', 'TileSpacing', 'none');
for i = 1:length(d)
    I = imread(fullfile(f,d(i).name));
    if size(I,3) > 1
        I = rgb2gray(I);
    end
    I = imresize(I,[50,50]);
    nexttile;
    imshow(I);
    imwrite(I, fullfile('Resized_Test', strcat(num2str(i,'%02d'), '_gray.jpg')));
end