close all;
clear all;
clc;
% Set up paths to the image folders
Images_path = './Resized_Images/';
Test_path = './Resized_Test/';

% Get a list of all image files in both folders
Images_files = dir(fullfile(Images_path, '*.jpg'));
Test_files = dir(fullfile(Test_path, '*.jpg'));

% Load all images into memory and concatenate their pixels into features
Images_features = zeros(length(Images_files), 2500);
for i = 1:length(Images_files)
    image = imread(fullfile(Images_path, Images_files(i).name));
    Images_features(i, :) = image(:)';
end

Test_features = zeros(length(Test_files), 2500);
for i = 1:length(Test_files)
    image = imread(fullfile(Test_path, Test_files(i).name));
    Test_features(i, :) = image(:)';
end

% For each image in Test folder, find the closest match in Images folder
for i = 1:length(Test_files)
    Test_image_feature = Test_features(i, :);
    distances = sum(bsxfun(@minus, Images_features, Test_image_feature).^2, 2);
    [~, closest_index] = min(distances);
    
    % Display the two images side by side
    figure;
    subplot(1, 2, 1);
    imshow(imread(fullfile(Test_path, Test_files(i).name)));
    title('Resized Test');
    subplot(1, 2, 2);
    imshow(imread(fullfile(Images_path, Images_files(closest_index).name)));
    title('Closest Match');
end