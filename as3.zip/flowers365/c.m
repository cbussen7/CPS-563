close all;
clear all;
clc;

% Define the path to the folder containing the resized images
path = 'Resized_Images/';

% Get a list of all the JPG files in the folder
filelist = dir([path '*.jpg']);

% Load the first image in the folder to determine its size
img = imread([path filelist(1).name]);
img_size = size(img);

% Load all the images in the folder into a 2D matrix
num_images = length(filelist);
image_data = [];
for i = 1:num_images
    filename = [path filelist(i).name];
    img = imread(filename);
    img = double(img(:));
    image_data = [image_data img];
end

% Perform PCA on the image data using the "pca" function
[PC, V] = pca(image_data);

% Visualize the first 15 eigenvectors obtained from PCA
figure;
for i = 1:15
    subplot(3, 5, i);
    eigenvector = reshape(PC(:, i), img_size);
    imagesc(eigenvector);
    colormap(gray);
    axis off;
    title(['Eigenvector #', num2str(i)]);
end