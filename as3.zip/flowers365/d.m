close all;
clear all;
clc;

% set path for resized images
resized_path = './Resized_Images/';
 
% Get a list of all image files in images folder
resized_files = dir(fullfile(resized_path, '*.jpg'));
 
% Load all images into memory and concatenate their pixels into features
resized_features = zeros(2500, length(resized_files));
for i = 1:length(resized_files)
    image = imread(fullfile(resized_path, resized_files(i).name));
    resized_features(:,i) = image(:);
end

% perform pca on matrix of features
[PC, V] = pca(resized_features);

% project images to 15 dimensions
projection = PC(:, 1:15);
 
image_projections = resized_features' * projection;
 
% create labels for each image
flower_labels = cell(length(resized_files), 1);
for i = 1:length(resized_files)
    if i >= 1 && i <= 10
        flower_labels{i} = 'Dandelion'; % dandelion
    elseif i >= 11 && i <= 20
        flower_labels{i} = 'Rose'; % rose
    elseif i >= 21 && i <= 30
        flower_labels{i} = 'Sunflower'; % sunflower
    elseif i >= 31 && i <= 40
        flower_labels{i} = 'Tulip'; % tulip
    end
end

% colors for each flower
% colors = [
%     1 1 0; % dandelion
%     1 0 0; % rose
%     0 1 0; % sunflower
%     1 0 1 % tulip
%     ];

% plot images with parallel coords
figure;
parallelcoords(image_projections, 'group',flower_labels); % ,'color', colors
xlabel('Dimension');
ylabel('Projection');
title('Image Projections using Parallel Coordinates');
legend('Location','best');