close all;
clear all;
clc;

% set path for resized images and test images
images_path = './Resized_Images/';
test_path = './Resized_Test/';
 
% Get a list of all image files in both folders
images_files = dir(fullfile(images_path, '*.jpg'));
test_files = dir(fullfile(test_path, '*.jpg'));

 
% Load all images into memory and concatenate their pixels into features
images_features = zeros(2500, length(images_files));
for i = 1:length(images_files)
    image = imread(fullfile(images_path, images_files(i).name));
    images_features(:,i) = image(:);
end

test_features = zeros(2500, length(test_files));
for i = 1:length(test_files)
    image = imread(fullfile(test_path, test_files(i).name));
    test_features(:,i) = image(:);
end

% perform pca on matrix of features
% [evector, score, evalue] = pca(images_features');
[PC, V] = pca(images_features);

% project images to 15 dimensions
% projection = evector(:, 1:15);
projection = PC(:, 1:15);
 
image_projections = images_features' * projection;

test_projections = test_features' * projection;

% create labels for each image
flower_labels = cell(length(images_files), 1);
for i = 1:length(images_files)
    if i >= 1 && i <= 10
        flower_labels{i} = 'Dandelion'; % dandelion
    elseif i >= 11 && i <= 20
        flower_labels{i} = 'Rose'; % rose
    elseif i >= 21 && i <= 30
        flower_labels{i} = 'Sunflower'; % sunflower
    elseif i >= 31 && i <= 40
        flower_labels{i} = 'Tulip'; % tulip
    end
end

test_labels = {'Test 1', 'Test 2', 'Test 3', 'Test 4', 'Test 5', 'Test 6', 'Test 7', 'Test 8'};

% plot images and tests with parallel coords
figure;
hold on;
parallelcoords(image_projections, 'group',flower_labels);
parallelcoords(test_projections, 'group',test_labels);
xlabel('Dimension');
ylabel('Projection');
title('Image Projections using Parallel Coordinates');
legend('Location','best');
hold off;

% CODE FOR JUST TESTS WITHOUT IMAGES AS WELL
% parallelcoords(test_projections, 'group',test_labels);
% xlabel('Dimension');
% ylabel('Projection');
% title('Image Projections using Parallel Coordinates');
% legend('Location','best');